#include "fire.h"


Fire::~Fire()
{

}

