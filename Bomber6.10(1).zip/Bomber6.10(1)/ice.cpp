#include "ice.h"

Ice::Ice()
{

}

Ice::~Ice()
{

}

