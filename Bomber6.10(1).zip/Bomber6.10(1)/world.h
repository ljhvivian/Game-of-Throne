#ifndef WORLD_H
#define WORLD_H
#include "rpgobj.h"
#include <vector>
#include <string>
#include <QPainter>
#include<set>
#include "character.h"
#include"weapon.h"
#include "monster.h"
#include "player.h"
#include "fire.h"
#include "ice.h"
class World
{
public:
    World(){}
    ~World(){}
    void initWorld(char* mapFile);
        //输入的文件中定义了初始状态下游戏世界有哪些对象，出生点在哪
    void show(QPainter * painter);
        //显示游戏世界所有对象
    void handlePlayerMove(int direction, int steps);
        //假定只有一个玩家
    void handleMonsterMove(int direction, int steps, Monster& m);
    void explodeObject(RPGObj r);
    void occurObject(RPGObj r);
    void playerProduceBomb();
    void monsterProduceBomb();
    void monsterMinus(RPGObj r);
    void bombTimeCount();
    void EWSNM(RPGObj r);
    void monsterMove(int direction,int steps);
    void FireEWSNM();
    //int getNum(Weapon *weapon){return weapon->getNumber();}
    int getFire(){return fire.getNumber();}
    void minusFire(){fire.minusWeapon();}
    void addFire(){fire.addWeapon();}
    //
    int getIce(){return fire.getNumber();}//
    void minusIce(){fire.minusWeapon();}//
    void addIce(){fire.addWeapon();}//
    int getBoAr(){return fire.getNumber();}//
    void minusBoAr(){fire.minusWeapon();}//
    void addBoAr(){fire.addWeapon();}//
    int getPlayerLife(){return _player.getLife();}
    bool getWP1(){return WP1;}
    bool getWP2(){return WP2;}
    bool getWP3(){return WP3;}
private:
    vector<RPGObj> _objs,_exploid,_fire;
    vector<Weapon> _bombs;
    vector<Monster> monster_;
    vector<Player> player_;
    Player _player;
    Fire fire;
    static  bool _over;
    static int _move;
    static int _directionChange;
    bool WP1=0,WP2=0,WP3=0;
};
#endif // WORLD_H
