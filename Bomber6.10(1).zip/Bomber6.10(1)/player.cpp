#include "player.h"

Player::Player()
{

}

Player::~Player()
{

}

