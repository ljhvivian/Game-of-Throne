#include "monster.h"

Monster::Monster()
{

}

Monster::~Monster()
{

}

