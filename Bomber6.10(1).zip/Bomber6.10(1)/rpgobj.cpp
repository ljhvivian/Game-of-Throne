#include "rpgobj.h"
#include <iostream>

void RPGObj::initObj(string type)
{
    //TODO 所支持的对象类型应定义为枚举
    if (type.compare("player1")==0){
        this->_coverable = false;
        this->_eatable = false;
        this->_bombable = false;
        this->_canfire = false;
        this->_canfreeze = false;
    }
    else if (type.compare("player2")==0){
        this->_coverable = false;
        this->_eatable = false;
        this->_bombable = false;
        this->_canfire = false;
        this->_canfreeze = false;
    }
    else if (type.compare("player3")==0){
        this->_coverable = false;
        this->_eatable = false;
        this->_bombable = false;
this->_canfire = false;
        this->_canfreeze = false;
    }
    else if (type.compare("player4")==0){
        this->_coverable = false;
        this->_eatable = false;
        this->_bombable = false;
        this->_canfire = false;
        this->_canfreeze = false;
    }
    else if (type.compare("stone")==0){
        this->_coverable = false;
        this->_eatable = false;
        this->_bombable =false;
        this->_canfire = false;
        this->_canfreeze = false;
    }
    else if (type.compare("fruit")==0){
        this->_coverable = true;
        this->_eatable = true;
        this->_bombable=false;
        this->_canfire = false;
        this->_canfreeze = false;
    }
    else if (type.compare("grass")==0){
        this->_coverable = true;
        this->_eatable = false;
        this->_bombable= false;
        this->_canfire = false;
        this->_canfreeze = false;
    }
    else if (type.compare("monster")==0){
        this->_coverable = false;
        this->_eatable = false;
        this->_bombable = false;
        this->_canfire = false;
        this->_canfreeze = false;
    }
    else if (type.compare("tree")==0){
        this->_coverable = false;
        this->_eatable = false;
        this->_bombable = true;
        this->_canfire = false;
        this->_canfreeze = false;
    }
    else if (type.compare("bomb")==0){
        this->_coverable = false;
        this->_eatable = false;
        this->_bombable = false;
        this->_canfire = false;
        this->_canfreeze = false;
    }
    else if (type.compare("exploid")==0){
        this->_coverable = true;
        this->_eatable = false;
        this->_bombable = false;
        this->_canfire = false;
        this->_canfreeze = false;
    }
    else if (type.compare("bodyarmor")==0){
        this->_coverable = true;
        this->_eatable = true;
        this->_bombable = false;
        this->_canfire = false;
        this->_canfreeze = false;
    }
    else if (type.compare("fire")==0){
        this->_coverable = true;
        this->_eatable = true;
        this->_bombable = false;
        this->_canfire = true;
        this->_canfreeze = false;
    }
    else if(type.compare("ice")==0){
        this->_coverable = true;
        this->_eatable = true;
        this->_bombable = false;
        this->_canfire = false;
        this->_canfreeze = false;
    }
    else if(type.compare("fire_explode")==0){
        this->_coverable = true;
        this->_eatable = true;
        this->_bombable = false;
        this->_canfire = false;
        this->_canfreeze = false;
    }
    else if(type.compare("bloodStrip")==0){
        this->_coverable = false;
        this->_eatable = false;
        this->_bombable = false;
        this->_canfire = false;
        this->_canfreeze = false;
    }
    else if(type.compare("blood")==0){
        this->_coverable = false;
        this->_eatable = false;
        this->_bombable = false;
        this->_canfire = false;
        this->_canfreeze = false;
    }
    else if(type.compare("WP1")==0){
        this->_coverable = false;
        this->_eatable = false;
        this->_bombable = false;
        this->_canfire = false;
        this->_canfreeze = false;
    }
    else if(type.compare("WP2")==0){
        this->_coverable = false;
        this->_eatable = false;
        this->_bombable = false;
        this->_canfire = false;
        this->_canfreeze = false;
    }
    else if(type.compare("WP3")==0){
        this->_coverable = false;
        this->_eatable = false;
        this->_bombable = false;
        this->_canfire = false;
        this->_canfreeze = false;
    }
    else{
        //TODO 应由专门的错误日志文件记录
        cout<<"invalid ICON type."<<endl;
        return;
    }

    this->_icon = ICON::findICON(type);
    QImage all;
    if(type.compare("player1")==0||type.compare("player2")==0||type.compare("player3")==0||type.compare("player4")==0){
        all.load("D:\\Bomber\\people.jpg");
        this->_pic = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        op=0;
    }
    else if(type.compare("fire")==0||type.compare("ice")==0||type.compare("fire_explode")==0){
        all.load("D:\\Bomber\\ice.png");
        this->_pic = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
    }
    else{
        all.load("D:\\Bomber\\TileB.png");
        this->_pic = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
    }
}

void RPGObj::show(QPainter * pa){
    int gSize = ICON::GRID_SIZE;
    pa->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_pic);
}
