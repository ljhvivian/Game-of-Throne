#ifndef FIRE_H
#define FIRE_H
#include "weapon.h"

class Fire:public Weapon
{
public:
    Fire(){}
    //int getNumber(){return number;}
    ~Fire();
private:
    //int number;
};

#endif // FIRE_H
