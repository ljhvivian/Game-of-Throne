#ifndef BODYARMOR_H
#define BODYARMOR_H
#include"rpgobj.h"

class bodyarmor: public RPGObj
{
public:
    bodyarmor();
    ~bodyarmor();
};

#endif // BODYARMOR_H
