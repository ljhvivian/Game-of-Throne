#include "bomb.h"

Bomb::Bomb()
{

}

Bomb::~Bomb()
{

}

