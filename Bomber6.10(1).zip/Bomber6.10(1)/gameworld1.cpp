#include "gameworld1.h"
#include "ui_gameworld1.h"
#include "icon.h"
#include"world.h"
#include <QTimer>
#include<QString>
#include <map>
int Gameworld1::_randomProduceBomb=0;
Gameworld1::Gameworld1(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Gameworld1)
{
    ui->setupUi(this);
    //init game world
    _game.initWorld("D:\\Bomber\\mapfile.txt");
    //init gameRecord notetable
    _gameRecord.initNoteTable();
    //以下是对时钟的初始化
    timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(randomMove()));//timeoutslot()为自定义槽
        //时钟事件与randomMove函数绑定
    timer->start(100);
    timer->setInterval(1000);

    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
        //设置随机数种子
    resize(1000,680);
}

Gameworld1::~Gameworld1()
{
    delete ui;
}

void Gameworld1::paintEvent(QPaintEvent *e){
    Q_UNUSED(e);
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    this->_game.show(pa);
    _gameRecord.loadWorld(_game);
    this->_gameRecord.show(pa);
    pa->end();
    delete pa;
    QPainter painter(this);
    QFont font;
    font.setPointSize(15);
    painter.setFont(font);
    painter.setPen(QPen(Qt::blue,10));
    const QString bombNum = QString(QString::fromLocal8Bit((_gameRecord.bombNum()).c_str()));
    const QString fireNum = QString(QString::fromLocal8Bit((_gameRecord.fireNum()).c_str()));
    const QString iceNum = QString(QString::fromLocal8Bit((_gameRecord.iceNum()).c_str()));
    const QString boArNum = QString(QString::fromLocal8Bit((_gameRecord.boArNum()).c_str()));
    painter.drawText(920,345,bombNum);
    painter.drawText(920,390,fireNum);
    painter.drawText(920,440,iceNum);
    painter.drawText(920,490,boArNum);
}

void Gameworld1::keyPressEvent(QKeyEvent *e)
{
    //direction = 1,2,3,4 for 上下左右
    if(e->key() == Qt::Key_A)
    {
        this->_game.handlePlayerMove(3,1);
    }
    else if(e->key() == Qt::Key_D)
    {
        this->_game.handlePlayerMove(4,1);
    }
    else if(e->key() == Qt::Key_W)
    {
        this->_game.handlePlayerMove(1,1);
    }
    else if(e->key() == Qt::Key_S)
    {
         this->_game.handlePlayerMove(2,1);
    }
    else if(e->key() == Qt::Key_Space)
    {
        this->_game.playerProduceBomb();
    }
    else if(e->key() == Qt::Key_B)
    {
        if(_game.getFire()>0){
        _game.FireEWSNM();
        _game.minusFire();}
    }
    this->repaint();
}


void Gameworld1::randomMove(){
    int d = 1 + rand()%4;
    this->_game.monsterMove(d,1);
    _randomProduceBomb++;
    if(_randomProduceBomb==5){
        _game.monsterProduceBomb();
        _randomProduceBomb=0;
    }
    _game.bombTimeCount();
    this->repaint();
}
