#include "bodyarmor.h"

bodyarmor::bodyarmor()
{

}

bodyarmor::~bodyarmor()
{

}

