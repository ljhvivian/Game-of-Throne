#ifndef WEAPON_H
#define WEAPON_H
#include "rpgobj.h"

class Weapon: public RPGObj
{
public:
    Weapon(){_timeCount=0;number=0;}
    ~Weapon();
    int getNumber(){return number;}
    void minusWeapon(){number--;}
    void addWeapon(){number++;}
    int _timeCount;
private:
    int number;
};

#endif // WEAPON_H
