#include <QApplication>
#include <QWidget>
#include <QDialog>
#include "gameworld1.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Gameworld1 dlg;
    dlg.show();//将Dialog 设置为模态对话框，程序运行到这一行就会阻塞了
    //return r;
    return a.exec();
}
