#ifndef ICE_H
#define ICE_H
#include "weapon.h"

class Ice: public Weapon
{
public:
    Ice();
    int getNumber(){return number;}
    ~Ice();
private:
    int number;
};

#endif // ICE_H
