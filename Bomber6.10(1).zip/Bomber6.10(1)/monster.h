#ifndef MONSTER_H
#define MONSTER_H
#include "character.h"

class Monster:public Character
{
public:
    Monster();
    ~Monster();
private:
};

#endif // MONSTER_H
