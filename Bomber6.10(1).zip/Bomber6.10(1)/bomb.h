#ifndef BOMB_H
#define BOMB_H


class Bomb
{
public:
    Bomb();
    ~Bomb();
};

#endif // BOMB_H
