#include "poison.h"

Poison::Poison()
{

}

Poison::~Poison()
{

}

