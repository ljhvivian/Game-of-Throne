#include "weapon.h"


Weapon::~Weapon()
{

}
