#include "ranking.h"
#include "ui_ranking.h"
#include<string>
#include<QPainter>
#include<string>
#include<iostream>
#include<fstream>
#include<sstream>
#include<map>
Ranking::Ranking(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Ranking)
{
    ui->setupUi(this);
}

Ranking::~Ranking()
{
    delete ui;
}

void Ranking::on_pushButton_clicked()
{
    close();
}

void Ranking::paintEvent(QPaintEvent *e)
{
    Q_UNUSED(e);
    QPainter painter(this);
    QFont font;
    font.setPointSize(15);
    painter.setFont(font);
    painter.setPen(QPen(Qt::red,10));
    std::map<std::string,int> m;
    std::map<std::string,int>::iterator it;
    std::string username;
    int score=0;
    std::string s="D:\\ranking.txt";
    const char* ch=s.c_str();
    std::ifstream infile(ch,std::ios::in);
    while(infile>>username>>score)  m[username]=score;
    infile.close();
    int wid=50;
    for(it=m.begin();it!=m.end();it++){
        std::string str1,str2;
        std::stringstream ss;
        ss<<it->second;
        ss>>str1;
        str2=it->first+"    "+str1;
        const QString qstr = QString(QString::fromLocal8Bit(str2.c_str()));
        painter.drawText(70,wid,qstr);
        wid+=30;
    }
}
